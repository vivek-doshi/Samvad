# Models Directory

This directory holds model files. Contents are excluded from git (.gitignore).

## Directory Layout

```
models/
├── arthvidya/
│   └── arthvidya-4b-q4_k_m.gguf     ← Arthvidya fine-tuned model (primary)
│   └── arthvidya-4b-q8_0.gguf       ← Higher quality option (more VRAM)
│
├── embeddings/
│   └── bge-small-en-v1.5/            ← Sentence transformer embedding model
│       ├── config.json
│       ├── tokenizer.json
│       └── model.safetensors
│
└── reranker/
    └── cross-encoder-ms-marco-MiniLM-L-6-v2/
        ├── config.json
        └── model.safetensors
```

## Download Commands

```bash
# Arthvidya (after training is complete)
# Copy from training WSL2:
# cp ~/finance_llm/checkpoints/merged/arthvidya-4b-q4_k_m.gguf models/arthvidya/

# Embedding model
pip install sentence-transformers
python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('BAAI/bge-small-en-v1.5')"

# Reranker
python -c "from sentence_transformers import CrossEncoder; CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')"
```

## VRAM Budget (RTX 5070 12GB)

| Component                | VRAM    |
|--------------------------|---------|
| Arthvidya 4B Q4_K_M      | ~2.5 GB |
| KV Cache (32K context)   | ~1.2 GB |
| BGE-small embedding      | ~0.1 GB |
| ChromaDB in-memory       | ~0.3 GB |
| OS / CUDA overhead       | ~1.5 GB |
| **Total**                | **~5.6 GB** |
| **Headroom**             | **~6.4 GB** |
